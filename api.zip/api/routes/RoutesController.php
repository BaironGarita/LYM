<?php

class RoutesController
{
    public function index()
    {
        $url = $_GET['url'] ?? '';

        $segments = explode('/', trim($url, '/'));

        if (count($segments) < 2) {
            $this->notFound();
            return;
        }

        $first = strtolower($segments[0]);
        $second = strtolower($segments[1]);

        if ($first === 'api') {

            switch ($second) {
                case 'productos':
                    $controller = new ProductoController();
                    $this->handleProductoRoutes($controller);
                    break;

                case 'categorias':
                    $controller = new CategoriaController();
                    $this->handleCategoriaRoutes($controller);
                    break;

                case 'etiquetas':
                    $controller = new EtiquetaController();
                    $this->handleEtiquetaRoutes($controller);
                    break;

                // Aquí puedes agregar más controladores si deseas...

                default:
                    $this->notFound();
                    break;
            }
        } else {
            $this->notFound();
        }
    }

    private function handleProductoRoutes($controller)
    {
        $method = $_SERVER['REQUEST_METHOD'];

        if ($method === 'GET') {
            if (isset($_GET['id'])) {
                $controller->get();
            } elseif (isset($_GET['categoria_id'])) {
                $controller->getByCategoria();
            } elseif (isset($_GET['q'])) {
                $controller->buscar();
            } else {
                $controller->index();
            }
        } elseif ($method === 'POST') {
            $controller->create();
        } elseif ($method === 'PUT') {
            $controller->update();
        } elseif ($method === 'DELETE') {
            $controller->delete();
        } else {
            $this->methodNotAllowed();
        }
    }

    private function handleCategoriaRoutes($controller)
    {
        $method = $_SERVER['REQUEST_METHOD'];

        if ($method === 'GET') {
            if (isset($_GET['id'])) {
                $controller->get();
            } else {
                $controller->index();
            }
        } elseif ($method === 'POST') {
            $controller->create();
        } elseif ($method === 'PUT') {
            $controller->update();
        } elseif ($method === 'DELETE') {
            $controller->delete();
        } else {
            $this->methodNotAllowed();
        }
    }

    private function handleEtiquetaRoutes($controller)
    {
        $method = $_SERVER['REQUEST_METHOD'];

        if ($method === 'GET') {
            if (isset($_GET['id'])) {
                $controller->get();
            } else {
                $controller->index();
            }
        } elseif ($method === 'POST') {
            $controller->create();
        } elseif ($method === 'PUT') {
            $controller->update();
        } elseif ($method === 'DELETE') {
            $controller->delete();
        } else {
            $this->methodNotAllowed();
        }
    }

    private function notFound()
    {
        http_response_code(404);
        echo json_encode(["error" => "Recurso no encontrado"]);
    }

    private function methodNotAllowed()
    {
        http_response_code(405);
        echo json_encode(["error" => "Método no permitido"]);
    }
}
